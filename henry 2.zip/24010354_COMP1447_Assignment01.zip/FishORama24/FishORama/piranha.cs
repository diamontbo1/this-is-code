﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using FishORamaEngineLibrary;
using SharpDX.Direct3D9;


namespace FishORama
{
    // Piranha

    class Piranha : IDraw
    {

        private string textureID;               
        
        private float xPosition;               
        private float yPosition;                
       
        private int xDirection;               
        private int yDirection;                 
       
        private Screen screen;                  
        private ITokenManager tokenManager;    

.
        private int xSpeed;                     // This is the horizontal speed of the Piranha.
        private int ySpeed;                     // And this is the vertical speed of the Piranha
        
        private Random rand;                    // This will generate a random number


        public Piranha(string pTextureID, float pXpos, float pYpos, Screen pScreen, ITokenManager pTokenManager, Random pRand)
        {
            textureID = pTextureID;  
            xPosition = pXpos;       
            yPosition = pYpos;      
            
            xDirection = 1;       
            yDirection = 1;         
            
            screen = pScreen;       
            tokenManager = pTokenManager;  
            rand = pRand;            


            xSpeed = rand.Next(2, 6);    // This will give a random horizontal speed between 2 and 5.
            ySpeed = 0;                  // No vertical speed 
            yPosition = rand.Next(0, (int)(screen.height * 0.66f));  // Its meant to start somewhere in the top two-thirds of the screen (not 100% functioning)
        }


        public void Update()
        {
            // Change direction if hitting screen edges.
            if (xPosition > screen.width / 2 || xPosition < -screen.width / 2)
            {
                xDirection *= -1;  // change horizontal direction.

                if (rand.Next(4) == 0)  // there is a chance to also flip vertical direction is 25%
                {
                    yDirection *= -1;
                }
            }

            if (yPosition > screen.height / 2 || yPosition < -screen.height / 2)
            {
                yDirection *= -1;  // change the vertical direction.

                if (rand.Next(2) == 0)  //  // there is a chance to also flip horizontal direction is 50%
                {
                    xDirection *= -1;
                }
            }

 
            xPosition += xSpeed * xDirection;
            yPosition += ySpeed * yDirection;
        }

        public void Draw(IGetAsset pAssetManager, SpriteBatch pSpriteBatch)
        {
           
            Asset currentAsset = pAssetManager.GetAssetByID(textureID);

           
            SpriteEffects horizontalDirection = xDirection < 0 ? SpriteEffects.FlipHorizontally : SpriteEffects.None;

           
            pSpriteBatch.Draw(
                currentAsset.Texture,                                             
                new Vector2(xPosition, yPosition * -1),                           
                null,                                                             
                Color.White,                                                      
                0f,                                                              
                new Vector2(currentAsset.Size.X / 2, currentAsset.Size.Y / 2),    
                new Vector2(1, 1),                                             
                horizontalDirection,                                              
                1                                                                 
            );
        }
    }
}
