﻿using FishORamaEngineLibrary;

namespace FishORama
{
    internal class Simulation
    {
        private Kernel kernel;
        private Screen screen;

        public Simulation(Kernel kernel)
        {
            this.kernel = kernel;
        }

        public TokenManager TokenManager { get; internal set; }
    }
}