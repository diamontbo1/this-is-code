﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using FishORamaEngineLibrary;

namespace FishORama
{
    public class Simulation : IUpdate, ILoadContent
    {
        private IKernel Kernel;  //runs the game.
        private Screen Screen;  // The screen size
        private ITokenManager tokenManager; 


        public ITokenManager TokenManager
        {
            set { tokenManager = value; }
        }

        // All the fish token this is for the fish to show up in the screen
        OrangeFish fish1;                       // This one is for the orange fish which is only one fish
        Urchin[] fish2 = new Urchin[3];  // This one is for the urchin there are 3 of these in an array
        Seahorses[] fish3 = new Seahorses[5]; // This one is for the seahorses there are 5 of these in an array
        Piranha fish4;                   // This one is for the piranha which there is only one
        Random rand;                    // This generates a random number



        public Simulation(IKernel pKernel)
        {
            kernel = (Kernel)pKernel;// Game engine kernel passed to the constructor when this class is created
            screen = kernel.Screen;// Sets the Screen
            rand = new Random(); // Generate random numbers


        }

        public void LoadContent(IGetAsset assetGrabber)
        {
            // This section creates the oragefish and adds all the propeties
            int orangeX = rand.Next(-405, 405);  // Random X 
            int orangeY = rand.Next(-405, 405);  // Random Y 
            //This puts the orangefish in a random place of the screen
            fish1 = new OrangeFish("OrangeFish", orangeX, orangeY, screen, tokenManager, rand); // This section makes the fish
            Kernel.InsertToken(fish1);            // And this adds it to the game.

            // This section creates the urchin and adds all the propeties to all of them as there are 3 of them
            for (int i = 0; i < fish2.Length; i++)
            {
                int spikeX = rand.Next(-405, 405);  // Random X 
                int spikeY = rand.Next(-405, 405);  // Random Y 
                Urchin newSpike = new Urchin("Urchin", spikeX, spikeY, screen, tokenManager, rand); // This section makes the fish
                fish2[i] = newSpike;              // This saves it in the list
                Kernel.InsertToken(newSpike);        // And this adds it to the game
            }

            // This section creates the seahorses and adds all the propeties to all of them as there are 5 of them
            for (int i = 0; i < fish3.Length; i++)
            {
                int horseX = rand.Next(-405, 405);  // Random X 
                int horseY = rand.Next(-405, 405);  // Random Y 
                Seahorses newHorse = new Seahorses("Seahorse", horseX, horseY, screen, tokenManager, rand); // This section makes the fish
                fish3[i] = newHorse;              // This saves it in the list
                Kernel.InsertToken(newHorse);         // And this adds it to the game
            }

            // This section creates the pirahna and adds all the propeties
            int chompX = rand.Next(-405, 405);  // Random X 
            int chompY = rand.Next(-405, 405);  // Random Y 
            fish4 = new Piranha("Piranha1", chompX, chompY, screen, tokenManager, rand);  // This section makes the fish
                Kernel.InsertToken(fish4);        // And this adds it to the game
        }


        public void Update(GameTime gameTime)
        {
            fish1.Update(); // This updates the oragnefish

            foreach (Urchin spike in fish2) // this updates all the urchin 3 of them
            {
                spike.Update();
            }

            foreach (Seahorses horse in fish3) // this updates the 5 seahorses
            {
                horse.Update();
            }

            fish4.Update(); // this updates the piranha
        }
    }
}
