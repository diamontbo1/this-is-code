﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using FishORamaEngineLibrary;

namespace FishORama
{
    // OrangeFish 
    class OrangeFish : IDraw
    {
        private string textureID; 
       
        private float xPosition;  
        private float yPosition; 
       
        private int xDirection;  
        private int yDirection;   
       
        private Screen screen;    
        private ITokenManager tokenManager; 

        int xSpeed; // How fast the fish moves left or right.
        int ySpeed; // How fast the fish moves up or down.
        
        Random rand; // This give a random number


        public OrangeFish(string pTextureID, float pXpos, float pYpos, Screen pScreen, ITokenManager pTokenManager, Random pRand)
        {
         
            textureID = pTextureID;
           
            xPosition = pXpos;
            yPosition = pYpos;
            
            xDirection = 1; // Start moving right.
            yDirection = 1; // Start moving up.
           
            screen = pScreen;
            
            tokenManager = pTokenManager;
           
            ySpeed = xSpeed / 2;      // Y is slower becuse is a division of x by 2
            xSpeed = rand.Next(2, 6); // Random speed for X from 2 to 5 because is one less than 6
            rand = pRand; // This give a random number
        }


        public void Update()
        {
            // If the fish goes too far left or righ it will turn it around.
            if (xPosition > screen.width / 2 || xPosition < -screen.width / 2)
            {
                xDirection *= -1; // this will flip the direction.

                if (rand.Next(4) == 0) //it will also flip the up or down too its meant to be a 25% chance
                {
                    yDirection *= -1;
                }
            }

            // If the fish goes too far up or down it will turn it around.
            if (yPosition > screen.height / 2 || yPosition < -screen.height / 2)
            {
                yDirection *= -1;

                if (rand.Next(2) == 0) // it will also flip the left or right too is a 50% chance
                {
                    xDirection *= -1;
                }
            }

            // It move the fish in the X and Y directions by the speed.
            xPosition += xSpeed * xDirection;
            yPosition += ySpeed * yDirection;
        }

        // This makes the fish show up on the screen.
        public void Draw(IGetAsset pAssetManager, SpriteBatch pSpriteBatch)
        {
            Asset currentAsset = pAssetManager.GetAssetByID(textureID); 

            SpriteEffects horizontalDirection; 

            if (xDirection < 0)
            {
              
                horizontalDirection = SpriteEffects.FlipHorizontally;
            }
            else
            {
             
                horizontalDirection = SpriteEffects.None;
            }

         
            pSpriteBatch.Draw(currentAsset.Texture,                        
                              new Vector2(xPosition, yPosition * -1),      
                              null,                                        
                              Color.White,                                 
                              0f,                                          
                              new Vector2(currentAsset.Size.X / 2, currentAsset.Size.Y / 2), 
                              new Vector2(1, 1),                         
                              horizontalDirection,                         
                              1);                                          
        }
    }
}
