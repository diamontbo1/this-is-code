﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using FishORamaEngineLibrary;

namespace FishORama
{
    // Urchin
    class Urchin : IDraw
    {

        private string textureID;      
       
        private float xPosition;        
        private float yPosition;        
        
        private int xDirection;        
        private int yDirection;         
       
        private Screen screen;          
        private ITokenManager tokenManager; 

        private int xSpeed;              //It gives a speed for the horizontal movement
        private int ySpeed;              //It gives a speed for the vertical movement
        private Random rand;            //this gives a random number

        public Urchin(string pTextureID, float pXpos, float pYpos, Screen pScreen, ITokenManager pTokenManager, Random pRand)
        {
            textureID = pTextureID; 
           
            xPosition = pXpos;       
            yPosition = pYpos;      
           
            xDirection = 1;         
            yDirection = 1;         
           
            screen = pScreen;       //this is the dimesions of the screen
            tokenManager = pTokenManager;  //This creates the token which is the fish
            rand = pRand;           //this give a random number

            
            xSpeed = rand.Next(1, 4);// this give a random horizontal speed from 1-3 
            ySpeed = 0; // Urchin does not move vertically
        }

        public void Update()
        {
            // Change direction if hitting screen edges.
            if (xPosition > screen.width / 2 || xPosition < -screen.width / 2)
            {
                xDirection *= -1; // this will flip the direction.

                if (rand.Next(4) == 0)  // there is a chance to also flip vertical direction is 25%
                {
                    yDirection *= -1;
                }
            }

            // Update position based on speed and direction.
            xPosition += xSpeed * xDirection;
        }

        public void Draw(IGetAsset pAssetManager, SpriteBatch pSpriteBatch)
        {

            Asset currentAsset = pAssetManager.GetAssetByID(textureID);

      
            SpriteEffects horizontalDirection = xDirection < 0 ? SpriteEffects.FlipHorizontally : SpriteEffects.None;

            pSpriteBatch.Draw(
                currentAsset.Texture,                                             
                new Vector2(xPosition, yPosition * -1),                          
                null,                                                             
                Color.White,                                                      
                0f,                                                              
                new Vector2(currentAsset.Size.X / 2, currentAsset.Size.Y / 2),    
                new Vector2(1, 1),                                                
                horizontalDirection,                                              
                1                                                                 
            );
        }
    }
}
