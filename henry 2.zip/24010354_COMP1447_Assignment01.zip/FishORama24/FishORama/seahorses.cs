﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using FishORamaEngineLibrary;



namespace FishORama
{
    //Seahorses 

    class Seahorses : IDraw
    {

        private string textureID;       
       
        private float xPosition;        
        private float yPosition;       
        
        private int xDirection;         
        private int yDirection;         
        
        private Screen screen;        
        private ITokenManager tokenManager;

       
        private int xSpeed;             //It gives a speed for the horizontal movement
        private int ySpeed;            //It gives a speed for the vertical movement
        private Random rand;            // This give a random number

        public Seahorses(string pTextureID, float pXpos, float pYpos, Screen pScreen, ITokenManager pTokenManager, Random pRand)
        {
            textureID = pTextureID; 
            xPosition = pXpos;       
            yPosition = pYpos;      
            xDirection = 1;          
            yDirection = 1;         
            screen = pScreen;       
            tokenManager = pTokenManager;  
            rand = pRand;            

          
            xSpeed = rand.Next(2, 6);  // Random speed between 2 and 5.
            ySpeed = xSpeed;          // This makes diagonal movement
        }

        public void Update()
        {
            // Change direction if hitting screen edges.
            if (xPosition > screen.width / 2 || xPosition < -screen.width / 2)
            {
                xDirection *= -1;// this will flip the direction.

                if (rand.Next(4) == 0)  // there is a chance to also flip vertical direction is 25%
                {
                    yDirection *= -1;
                }
            }
            // Change direction if hitting screen edges.
            if (yPosition > screen.height / 2 || yPosition < -screen.height / 2)
            {
                yDirection *= -1; // this will flip the direction.

                if (rand.Next(2) == 0) // there is a chance to also flip horizontal direction is 50%
                {
                    xDirection *= -1;
                }
            }

            // Update position taking into consideration the speed and direction.
            xPosition += xSpeed * xDirection;
            yPosition += ySpeed * yDirection;
        }


        public void Draw(IGetAsset pAssetManager, SpriteBatch pSpriteBatch)
        {

            Asset currentAsset = pAssetManager.GetAssetByID(textureID);

      
            SpriteEffects horizontalDirection = xDirection < 0 ? SpriteEffects.FlipHorizontally : SpriteEffects.None;

            pSpriteBatch.Draw(
                currentAsset.Texture,                                            
                new Vector2(xPosition, yPosition * -1),                         
                null,                                                            
                Color.White,                                                      
                0f,                                                              
                new Vector2(currentAsset.Size.X / 2, currentAsset.Size.Y / 2),    
                new Vector2(1, 1),                                                
                horizontalDirection,                                              
                1                                                                 
            );
        }
    }
}
