﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using FishORamaEngineLibrary;

namespace FishORama
{
    // This thing makes the fish and other stuff show up and do stuff.
    public class FishSim : IUpdate, ILoadContent
    {
        // Stuff for the game.
        private IKernel gameKernel;  // The main thing that runs the game.
        private Screen gameScreen;  // The screen size thing.
        private ITokenManager stuffManager; // Manages random stuff. Probably important.

        // This is for the chicken leg (I don't know why it's here, but it is).
        public ITokenManager StuffManager
        {
            set { stuffManager = value; }
        }

        // All the fish and things.
        OrangeFish fish1;                       // The orange fish dude.
        Urchin[] fish2 = new Urchin[3];  // A bunch of spiky things (3 of them).
        Seahorses[] fish3 = new Seahorses[5]; // These are the seahorses (5 of them).
        Piranha fish4;                   // The angry fish.
        Random rand;                    // Makes random numbers happen.

        // This happens when the simulation starts. Sets stuff up.
        public FishSim(IKernel kernelThing)
        {
            gameKernel = kernelThing;           // Save the main game thingy.
            gameScreen = kernelThing.Screen;    // Get the screen size.
            rand = new Random();          // Make a random number thingy.
        }

        // This runs once to make all the fish and stuff show up.
        public void LoadContent(IGetAsset assetGrabber)
        {
            // Make the orange fish.
            int startX = rand.Next(-400, 401);  // Random X spot.
            int startY = rand.Next(-400, 401);  // Random Y spot.
            fish1 = new OrangeFish("OrangeFish", startX, startY, gameScreen, stuffManager, rand); // Make the fish.
            gameKernel.InsertToken(fish1);            // Add it to the game.

            // Make some spiky things.
            for (int i = 0; i < fish2.Length; i++)
            {
                int spikeX = rand.Next(-400, 401);  // Random X spot.
                int spikeY = rand.Next(-400, 401);  // Random Y spot.
                Urchin newSpike = new Urchin("Urchin", spikeX, spikeY, gameScreen, stuffManager, rand); // Make a fish2 guy.
                fish2[i] = newSpike;              // Save it in the list.
                gameKernel.InsertToken(newSpike);       // Add it to the game.
            }

            // Make some seahorses.
            for (int i = 0; i < fish3.Length; i++)
            {
                int horseX = rand.Next(-400, 401);  // Random X spot.
                int horseY = rand.Next(-400, 401);  // Random Y spot.
                Seahorses newHorse = new Seahorses("Seahorse", horseX, horseY, gameScreen, stuffManager, rand); // Make a fish3.
                fish3[i] = newHorse;              // Save it in the list.
                gameKernel.InsertToken(newHorse);        // Add it to the game.
            }

            // Make the chompy fish.
            int chompX = rand.Next(-400, 401);  // Random X spot.
            int chompY = rand.Next(-400, 401);  // Random Y spot.
            fish4 = new Piranha("Piranha1", chompX, chompY, gameScreen, stuffManager, rand); // Make the fish4.
            gameKernel.InsertToken(fish4);       // Add it to the game.
        }

        // This runs all the time (like 60 times a second) to update stuff.
        public void Update(GameTime gameTime)
        {
            fish1.Update(); // Move the fish1.

            foreach (Urchin spike in fish2) // Move all the fish2.
            {
                spike.Update();
            }

            foreach (Seahorses horse in fish3) // Move all the fish3.
            {
                horse.Update();
            }

            fish4.Update(); // Move the fish4.
        }
    }
}
