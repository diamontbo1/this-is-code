﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using FishORamaEngineLibrary;

/* FISHORAMA24 | .NET 6.0 | C.Blythe */

namespace FishORama
{
    /// CLASS: Seahorses - represents a token for the FishORama engine.
    /// Handles the behavior and drawing of Seahorses in the simulation.
    class Seahorses : IDraw
    {
        // CLASS VARIABLES
        private string textureID;       // ID of the texture used for this token.
        private float xPosition;        // Current X position on the screen.
        private float yPosition;        // Current Y position on the screen.
        private int xDirection;         // Horizontal movement direction (-1 = left, 1 = right).
        private int yDirection;         // Vertical movement direction (-1 = down, 1 = up).
        private Screen screen;          // Reference to screen dimensions.
        private ITokenManager tokenManager; // Reference to the token manager.

        // Additional variables for movement
        private int xSpeed;             // Speed of horizontal movement.
        private int ySpeed;             // Speed of vertical movement (equal to xSpeed for diagonal movement).
        private Random rand;            // Random number generator for behavior.

        /// CONSTRUCTOR: Initializes a Seahorses instance with its starting properties.
        public Seahorses(string pTextureID, float pXpos, float pYpos, Screen pScreen, ITokenManager pTokenManager, Random pRand)
        {
            textureID = pTextureID;  // Assign the texture ID.
            xPosition = pXpos;       // Set initial X position.
            yPosition = pYpos;       // Set initial Y position.
            xDirection = 1;          // Start moving right.
            yDirection = 1;          // Start moving upward.
            screen = pScreen;        // Store screen dimensions.
            tokenManager = pTokenManager;  // Assign the token manager.
            rand = pRand;            // Assign the random generator.

            // Initialize speed and set diagonal movement.
            xSpeed = rand.Next(2, 6);  // Random speed between 2 and 5.
            ySpeed = xSpeed;          // Diagonal movement (same speed for X and Y).
        }

        /// METHOD: Update - Handles Seahorses movement and behavior.
        public void Update()
        {
            // Reverse direction when hitting screen edges.
            if (xPosition > screen.width / 2 || xPosition < -screen.width / 2)
            {
                xDirection *= -1; // Flip horizontal direction.

                if (rand.Next(4) == 0) // 25% chance to flip vertical direction.
                {
                    yDirection *= -1;
                }
            }

            if (yPosition > screen.height / 2 || yPosition < -screen.height / 2)
            {
                yDirection *= -1; // Flip vertical direction.

                if (rand.Next(2) == 0) // 50% chance to flip horizontal direction.
                {
                    xDirection *= -1;
                }
            }

            // Update position based on speed and direction.
            xPosition += xSpeed * xDirection;
            yPosition += ySpeed * yDirection;
        }

        /// METHOD: Draw - Renders the Seahorse on the screen.
        /// This method is called by the FishORama engine.
        public void Draw(IGetAsset pAssetManager, SpriteBatch pSpriteBatch)
        {
            // Get the texture for this token.
            Asset currentAsset = pAssetManager.GetAssetByID(textureID);

            // Determine whether to flip the texture horizontally.
            SpriteEffects horizontalDirection = xDirection < 0 ? SpriteEffects.FlipHorizontally : SpriteEffects.None;

            // Draw the texture, centered at the Seahorse's position.
            pSpriteBatch.Draw(
                currentAsset.Texture,                                             // Texture to draw.
                new Vector2(xPosition, yPosition * -1),                           // Position on the screen.
                null,                                                             // No source rectangle.
                Color.White,                                                      // No color tint.
                0f,                                                               // No rotation.
                new Vector2(currentAsset.Size.X / 2, currentAsset.Size.Y / 2),    // Center the texture.
                new Vector2(1, 1),                                                // Scale (1x1).
                horizontalDirection,                                              // Flip or don't flip based on direction.
                1                                                                 // Layer depth.
            );
        }
    }
}
