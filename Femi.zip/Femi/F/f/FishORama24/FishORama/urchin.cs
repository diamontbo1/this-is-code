﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using FishORamaEngineLibrary;

namespace FishORama
{
    /// CLASS: Urchin - represents a token for the FishORama engine.
    /// Handles the movement and rendering of an Urchin in the simulation.
    class Urchin : IDraw
    {
        // CLASS VARIABLES
        private string textureID;       // ID of the texture used for this token.
        private float xPosition;        // Current X position on the screen.
        private float yPosition;        // Current Y position on the screen.
        private int xDirection;         // Horizontal movement direction (-1 = left, 1 = right).
        private int yDirection;         // Vertical movement direction (-1 = down, 1 = up).
        private Screen screen;          // Reference to screen dimensions.
        private ITokenManager tokenManager; // Reference to the token manager.

        // Movement-specific variables
        private int xSpeed;             // Speed of horizontal movement.
        private int ySpeed;             // Speed of vertical movement (unused, set to 0).
        private Random rand;            // Random number generator for behavior.

        /// CONSTRUCTOR: Initializes the Urchin with starting properties.
        public Urchin(string pTextureID, float pXpos, float pYpos, Screen pScreen, ITokenManager pTokenManager, Random pRand)
        {
            textureID = pTextureID;  // Assign the texture ID.
            xPosition = pXpos;       // Set initial X position.
            yPosition = pYpos;       // Set initial Y position.
            xDirection = 1;          // Start moving right.
            yDirection = 1;          // Default vertical direction (not used here).
            screen = pScreen;        // Store screen dimensions.
            tokenManager = pTokenManager;  // Assign the token manager.
            rand = pRand;            // Assign the random generator.

            // Initialize horizontal speed (1-3) and set no vertical movement.
            xSpeed = rand.Next(1, 4);
            ySpeed = 0; // Urchin does not move vertically.
        }

        /// METHOD: Update - Handles Urchin movement.
        public void Update()
        {
            // Reverse direction when hitting screen edges.
            if (xPosition > screen.width / 2 || xPosition < -screen.width / 2)
            {
                xDirection *= -1; // Flip horizontal direction.

                if (rand.Next(4) == 0) // 25% chance to randomly flip vertical direction (even if unused here).
                {
                    yDirection *= -1;
                }
            }

            // Update position based on speed and direction.
            xPosition += xSpeed * xDirection;
        }

        /// METHOD: Draw - Renders the Urchin on the screen.
        /// This method is called repeatedly by the FishORama engine.
        public void Draw(IGetAsset pAssetManager, SpriteBatch pSpriteBatch)
        {
            // Get the texture for this token.
            Asset currentAsset = pAssetManager.GetAssetByID(textureID);

            // Determine whether to flip the texture horizontally.
            SpriteEffects horizontalDirection = xDirection < 0 ? SpriteEffects.FlipHorizontally : SpriteEffects.None;

            // Draw the texture, centered at the Urchin's position.
            pSpriteBatch.Draw(
                currentAsset.Texture,                                             // Texture to draw.
                new Vector2(xPosition, yPosition * -1),                           // Position on the screen.
                null,                                                             // No source rectangle.
                Color.White,                                                      // No color tint.
                0f,                                                               // No rotation.
                new Vector2(currentAsset.Size.X / 2, currentAsset.Size.Y / 2),    // Center the texture.
                new Vector2(1, 1),                                                // Scale (1x1).
                horizontalDirection,                                              // Flip or don't flip based on direction.
                1                                                                 // Layer depth.
            );
        }
    }
}
