﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using FishORamaEngineLibrary;

namespace FishORama
{
    // OrangeFish is the thing that moves on the screen and looks like a fish.
    // This uses some engine thing called Token to do stuff like moving and drawing.
    class OrangeFish : IDraw
    {
        // Stuff for the class
        // These are like the important things that make the fish work.
        private string textureID; // This is the name of the picture for the fish.
        private float xPosition;  // The fish's X spot on the screen.
        private float yPosition;  // The fish's Y spot on the screen.
        private int xDirection;   // Direction for X
        private int yDirection;   // Direction for Y
        private Screen screen;    // This is the screen size and stuff.
        private ITokenManager tokenManager; // Some manager thing. I don't know. Just leave it.

        // Some more random stuff.
        int xSpeed; // How fast the fish moves left or right.
        int ySpeed; // How fast the fish moves up or down.
        Random rand; // Random stuff happens with this.

        // This is the constructor. It sets up the fish.
        public OrangeFish(string pTextureID, float pXpos, float pYpos, Screen pScreen, ITokenManager pTokenManager, Random pRand)
        {
            // Give all the variables their starting values.
            textureID = pTextureID;
            xPosition = pXpos;
            yPosition = pYpos;
            xDirection = 1; // Start moving right.
            yDirection = 1; // Start moving up.
            screen = pScreen;
            tokenManager = pTokenManager;
            rand = pRand; // Random number generator thingy.
            xSpeed = rand.Next(2, 6); // Random speed for X (like 2 to 5).
            ySpeed = xSpeed / 2;      // Y is just slower, half the speed.
        }

        // This runs over and over to make the fish move.
        public void Update()
        {
            // If the fish goes too far left or right, turn it around.
            if (xPosition > screen.width / 2 || xPosition < -screen.width / 2)
            {
                xDirection *= -1; // Flip direction.

                if (rand.Next(4) == 0) // Sometimes flip the up or down too.
                {
                    yDirection *= -1;
                }
            }

            // If the fish goes too far up or down, turn it around.
            if (yPosition > screen.height / 2 || yPosition < -screen.height / 2)
            {
                yDirection *= -1;

                if (rand.Next(2) == 0) // Sometimes flip the left or right too.
                {
                    xDirection *= -1;
                }
            }

            // Move the fish in the X and Y directions by its speed.
            xPosition += xSpeed * xDirection;
            yPosition += ySpeed * yDirection;
        }

        // This makes the fish show up on the screen.
        public void Draw(IGetAsset pAssetManager, SpriteBatch pSpriteBatch)
        {
            Asset currentAsset = pAssetManager.GetAssetByID(textureID); // Get the picture for this fish.

            SpriteEffects horizontalDirection; // Do we flip the picture?

            if (xDirection < 0)
            {
                // If moving left, flip the picture.
                horizontalDirection = SpriteEffects.FlipHorizontally;
            }
            else
            {
                // If moving right, don't flip it.
                horizontalDirection = SpriteEffects.None;
            }

            // Draw the fish in the right spot, flipped or not.
            pSpriteBatch.Draw(currentAsset.Texture,                        // The picture.
                              new Vector2(xPosition, yPosition * -1),      // Where the fish goes.
                              null,                                        // No source rectangle. Who cares.
                              Color.White,                                 // It's not tinted or anything.
                              0f,                                          // No rotation. Fish don't spin.
                              new Vector2(currentAsset.Size.X / 2, currentAsset.Size.Y / 2), // Draw from center.
                              new Vector2(1, 1),                           // Size stays the same.
                              horizontalDirection,                         // Flip if needed.
                              1);                                          // Layer depth or something.
        }
    }
}
