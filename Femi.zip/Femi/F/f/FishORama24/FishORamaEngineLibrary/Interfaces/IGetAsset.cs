﻿namespace FishORamaEngineLibrary
{
    public interface IGetAsset
    {
        Asset GetAssetByID(string pKey);
    }
}

