﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using FishORamaEngineLibrary;



namespace FishORama
{
    /// CLASS: Seahorses 
    class Seahorses : IDraw
    {
        // CLASS VARIABLES
        private string textureID;      
        private float xPosition;     
        private float yPosition;       
        private int xDirection;        
        private int yDirection;        
        private Screen screen;         
        private ITokenManager tokenManager; 

        //  Movement
        private int xSpeed;            // Speed for horizontal 
        private int ySpeed;            // Speed for vertical
        private Random rand;            // Random number 

        /// CONSTRUCTOR:
        public Seahorses(string pTextureID, float pXpos, float pYpos, Screen pScreen, ITokenManager pTokenManager, Random pRand)
        {
            textureID = pTextureID;  
            xPosition = pXpos;       
            yPosition = pYpos;       
            xDirection = 1;          
            yDirection = 1;          
            screen = pScreen;        
            tokenManager = pTokenManager;
            rand = pRand;         

          
            xSpeed = rand.Next(2, 6);  // Random speed 2 and 6.
            ySpeed = xSpeed;        // vertical speed is dependate on horizontal
        }

        /// METHOD: Update
        public void Update()
        {
            // turn when it hits the edge.
            if (xPosition > screen.width / 2 || xPosition < -screen.width / 2)
            {
                xDirection *= -1; // horizontal direction.

                if (rand.Next(100) < 25) // has a chance to change direction
                {
                    yDirection *= -1;
                }
            }

            if (yPosition > screen.height / 2 || yPosition < -screen.height / 2)
            {
                yDirection *= -1; // Flip vertical direction.
            }

            // Update 
            xPosition += xSpeed * xDirection;
            yPosition += ySpeed * yDirection;
        }

        /// METHOD: Draw 
        public void Draw(IGetAsset pAssetManager, SpriteBatch pSpriteBatch)
        {
            Asset currentAsset = pAssetManager.GetAssetByID(textureID);

            SpriteEffects horizontalDirection = xDirection < 0 ? SpriteEffects.FlipHorizontally : SpriteEffects.None;

            pSpriteBatch.Draw(
                currentAsset.Texture,                                             
                new Vector2(xPosition, yPosition * -1),                           
                null,                                                           
                Color.White,                                                     
                0f,                                                             
                new Vector2(currentAsset.Size.X / 2, currentAsset.Size.Y / 2),    
                new Vector2(1, 1),                                                
                horizontalDirection,                                              
                1                                                                .
            );
        }
    }
}
