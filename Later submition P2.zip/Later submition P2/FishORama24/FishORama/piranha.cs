﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using FishORamaEngineLibrary;
using SharpDX.Direct3D9;


namespace FishORama
{
    /// CLASS: Piranha 
    class Piranha : IDraw
    {
        // CLASS VARIABLES
        private string textureID;              
        private float xPosition;                
        private float yPosition;
        private int xDirection;
        private int yDirection;                 
        private Screen screen;                 
        private ITokenManager tokenManager;    
        private int xSpeed;                     
        private int ySpeed;                     
        private Random rand;                    ]
        /// CONSTRUCTOR: 
        public Piranha(string pTextureID, float pXpos, float pYpos, Screen pScreen, ITokenManager pTokenManager, Random pRand)
        {
            textureID = pTextureID;  
            xPosition = pXpos;       
            yPosition = pYpos;       
            xDirection = 1;          
            yDirection = 1;         
            screen = pScreen;        
            tokenManager = pTokenManager;  
            rand = pRand;            

            xSpeed = rand.Next(2, 6);    // Random speed between 2 and 5
            ySpeed = 0;
            yPosition = rand.Next(0, (int)(screen.height * 0.66f)); // Start somewhere in the top of the screen
        }

        /// METHOD: Update
        public void Update()
        {
            // Reverse direction if edges.
            if (xPosition > screen.width / 2 || xPosition < -screen.width / 2)
            {
                xDirection *= -1;  

                if (rand.Next(100) < 25)  //chance of changing direction
                {
                    yDirection *= -1;
                }
            }

            if (yPosition > screen.height / 2 || yPosition < -screen.height / 2)
            {
                yDirection *= -1;  

            }

            // Update position 
            xPosition += xSpeed * xDirection;
            yPosition += ySpeed * yDirection;
        }

        /// METHOD: Draw
        public void Draw(IGetAsset pAssetManager, SpriteBatch pSpriteBatch)
        {
            Asset currentAsset = pAssetManager.GetAssetByID(textureID);


            SpriteEffects horizontalDirection = xDirection < 0 ? SpriteEffects.FlipHorizontally : SpriteEffects.None;

            pSpriteBatch.Draw(
                currentAsset.Texture,                                             
                new Vector2(xPosition, yPosition * -1),                           
                null,                                                             
                Color.White,                                                      
                0f,                                                              
                new Vector2(currentAsset.Size.X / 2, currentAsset.Size.Y / 2),   
                new Vector2(1, 1),                                               
                horizontalDirection,                                              
                1                                                               
            );
        }
    }
}
