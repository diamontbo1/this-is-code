﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using FishORamaEngineLibrary;

namespace FishORama
{

    public class FishSim : IUpdate, ILoadContent
    {
        private IKernel gameKernel;  
        private Screen gameScreen;  //screen size
        private ITokenManager stuffManager; 

      
        public ITokenManager StuffManager
        {
            set { stuffManager = value; }
        }

        // All the fish and things.
        OrangeFish orangefish;                       // The orangefiah
        Urchin[] urchin1 = new Urchin[3];  //URCHIN (3 of them).
        Seahorses[] seahorses = new Seahorses[5]; // seahorses (5 of them).
        Piranha piranha;                   // The pirahna
        Random rand;                    //  random numbers 

        public FishSim(IKernel kernelThing)
        {
            gameKernel = kernelThing;           
            gameScreen = kernelThing.Screen;
            rand = new Random();          
        }
        public void LoadContent(IGetAsset assetGrabber)
        {
            //orangefish.
            int OfishX = rand.Next(-400, 400);
            int OfishY = rand.Next(-400, 400);
            orangefish = new OrangeFish("OrangeFish", OfishX, OfishY, gameScreen, stuffManager, rand); // Make the orangefish.
            gameKernel.InsertToken(orangefish);            // Adds it to the game.

            // Make some Urchin
            for (int i = 0; i < urchin1.Length; i++)
            {
                int UfishX = rand.Next(-400, 400);  
                int UfishY = rand.Next(-400, 400);  
                Urchin urchins = new Urchin("Urchin", UfishX, UfishY, gameScreen, stuffManager, rand); // Make a urchin
                urchin1[i] = urchins;              // Save it in the list.
                gameKernel.InsertToken(urchins);       // Add it to the game.
            }

            // Make some seahorses.
            for (int i = 0; i < seahorses.Length; i++)
            {
                int SfishX = rand.Next(-400, 400);  // Random X spot.
                int SfishY = rand.Next(-400, 400);  // Random Y spot.
                Seahorses seahorses1 = new Seahorses("Seahorse", SfishX, SfishY, gameScreen, stuffManager, rand); // Make a seahorse
                seahorses[i] = seahorses1;              // Save it in the list.
                gameKernel.InsertToken(seahorses1);        // Add it to the game.
            }

            // Make the piranha
            int PfishX = rand.Next(-400, 400);  // Random X spot.
            int PfishY = rand.Next(-400, 400);  // Random Y spot.
            piranha = new Piranha("Piranha1", PfishX, PfishY, gameScreen, stuffManager, rand); // Make the piranha
            gameKernel.InsertToken(piranha);       // Add it to the game.
        }

        public void Update(GameTime gameTime)
        {
            orangefish.Update(); // Move the orangefish

            foreach (Urchin spike in urchin1) // Move all the urchin
            {
                spike.Update();
            }

            foreach (Seahorses horse in seahorses) // Move all the seahorse
            {
                horse.Update();
            }

            piranha.Update(); // Move the piranha
        }
    }
}
