﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using FishORamaEngineLibrary;

namespace FishORama
{
    /// CLASS: Urchin 
    class Urchin : IDraw
    {
        // CLASS VARIABLES
        private string textureID;      
        private float xPosition;     
        private float yPosition;       
        private int xDirection;        
        private int yDirection;      
        private Screen screen;         
        private ITokenManager tokenManager;

        // Movement
        private int xSpeed;             // Speed for horizontal 
        private int ySpeed;             // Speed for vertical 
        private Random rand;           

        /// CONSTRUCTOR: 
        public Urchin(string pTextureID, float pXpos, float pYpos, Screen pScreen, ITokenManager pTokenManager, Random pRand)
        {
            textureID = pTextureID; 
            xPosition = pXpos;       
            yPosition = pYpos;      
            xDirection = 1;          // horizontal movement.
            yDirection = 1;          //vertical movement
            screen = pScreen;        
            tokenManager = pTokenManager;  
            rand = pRand;            // random number.

            xSpeed = rand.Next(1, 4);//moves at a random speed in 1 and 4
            ySpeed = 0; // Urchin can't move vertically
        }

        /// METHOD:
        public void Update()
        {
            // turn when it hits the edge.
            if (xPosition > screen.width / 2 || xPosition < -screen.width / 2)
            {
                xDirection *= -1; 

                if (rand.Next(100) < 25) //has a chance of changing direction
                {
                    yDirection *= -1;
                }
            }

            // Update position 
            xPosition += xSpeed * xDirection;
            yPosition += ySpeed * yDirection;
        }

        /// METHOD: Draw - Renders the Urchin on the screen.
        public void Draw(IGetAsset pAssetManager, SpriteBatch pSpriteBatch)
        {
            Asset currentAsset = pAssetManager.GetAssetByID(textureID);

            SpriteEffects horizontalDirection = xDirection < 0 ? SpriteEffects.FlipHorizontally : SpriteEffects.None;

            pSpriteBatch.Draw(
                currentAsset.Texture,                                             
                new Vector2(xPosition, yPosition * -1),                          
                null,                                                             
                Color.White,                                                     
                0f,                                                              
                new Vector2(currentAsset.Size.X / 2, currentAsset.Size.Y / 2),   
                new Vector2(1, 1),                                                
                horizontalDirection,                                           
                1                                                                
            );
        }
    }
}
