﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using FishORamaEngineLibrary;

namespace FishORama
{
    // OrangeFish 
    class OrangeFish : IDraw
    {

        private string textureID; 
        private float xPosition; 
        private float yPosition;  
        private int xDirection;   
        private int yDirection; 
        private Screen screen;   
        private ITokenManager tokenManager;

      
        int xSpeed; 
        int ySpeed; 
        Random rand;

        ///Constructor
        public OrangeFish(string pTextureID, float pXpos, float pYpos, Screen pScreen, ITokenManager pTokenManager, Random pRand)
        {
         
            textureID = pTextureID;
            xPosition = pXpos;
            yPosition = pYpos;
            xDirection = 1; 
            yDirection = 1; 
            screen = pScreen;
            tokenManager = pTokenManager;
            rand = pRand; // Random number 
            xSpeed = rand.Next(2, 6); // Random speed for horizontal
            ySpeed = xSpeed / 2;      // verticall is divided by half making it slower
        }

   
        public void Update()
        {

            if (xPosition > screen.width / 2 || xPosition < -screen.width / 2)
            {
                xDirection *= -1; // Flip direction.

                if (rand.Next(4) == 0) // chance of changing direction 25%
                {
                    yDirection *= -1;
                }
            }


            if (yPosition > screen.height / 2 || yPosition < -screen.height / 2)
            {
                yDirection *= -1;

                if (rand.Next(2) == 0) // chance of changing direction 50%
                {
                    xDirection *= -1;
                }
            }

           
            xPosition += xSpeed * xDirection;
            yPosition += ySpeed * yDirection;
        }

        public void Draw(IGetAsset pAssetManager, SpriteBatch pSpriteBatch)
        {
            Asset currentAsset = pAssetManager.GetAssetByID(textureID); 

            SpriteEffects horizontalDirection; 

            if (xDirection < 0)
            {
  
                horizontalDirection = SpriteEffects.FlipHorizontally;
            }
            else
            {
                horizontalDirection = SpriteEffects.None;
            }
            pSpriteBatch.Draw(currentAsset.Texture,                        
                              new Vector2(xPosition, yPosition * -1),    
                              null,                                       
                              Color.White,                               
                              0f,                                         
                              new Vector2(currentAsset.Size.X / 2, currentAsset.Size.Y / 2), 
                              new Vector2(1, 1),                           
                              horizontalDirection,                        
                              1);                                          
        }
    }
}
