﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using FishORamaEngineLibrary;
using SharpDX.Direct3D9;

/* FISHORAMA24 | .NET 6.0 | C.Blythe */

namespace FishORama
{
    /// CLASS: Piranha
    class Piranha : IDraw
    {
        // CLASS VARIABLES
        private string textureID; // texture asset 
        private float xPosition; // X coordinate 
        private float yPosition; // Y coordinate
        private int xDirection; // Horizontal movement 
        private int yDirection; // Vertical movement 
        private Screen screen; // Screen dimensions.
        private ITokenManager tokenManager; // token manager 
        private int xSpeed; // Horizontal movement speed.
        private int ySpeed;// Vertical movement speed
        private Random rand; // Random number generator 

        /// CONSTRUCTOR: Piranha
        public Piranha(string pTextureID, float pXpos, float pYpos, Screen pScreen, ITokenManager pTokenManager, Random pRand)
        {
            //properties.
            textureID = pTextureID;
            xPosition = pXpos;
            yPosition = pYpos;
            xDirection = 1;  
            yDirection = 1; 
            screen = pScreen;
            tokenManager = pTokenManager;
            rand = pRand;
            xSpeed = rand.Next(2, 6); // Random speed between 2 and 5 
            ySpeed = 0;              // Default to no vertical movement.

            // Position the piranha in the top two-thirds 
            yPosition = rand.Next(0, (int)(screen.height * 0.66f));
        }

        /// METHOD: Update
        public void Update()
        {
            var chickenLeg = tokenManager.ChickenLeg;
            // Check if a ChickenLeg iis in the scene
            if (chickenLeg != null)
            {
                // Move towards the ChickenLeg.
                float movementX = chickenLeg.Position.X;// X position of the ChickenLeg.
                float movementY = chickenLeg.Position.Y;// y position of the ChickenLeg.
                // Calculate the distance between the Piranha and the ChickenLeg.
                float dx = movementX - xPosition;// Difference in X coordinates.
                float dy = movementY - yPosition; //Difference in y coordinates.
                float distance = (float)Math.Sqrt(dx * dx + dy * dy); // Calculate the straightline distance to the ChickenLeg.
                                                                      // Reference: GeeksforGeeks - C# Math.Sqrt() Method
                                                                      // The Math.Sqrt()is used to calculate the square root of a number
                                                                      //visit: https://www.geeksforgeeks.org/c-sharp-math-sqrt-method/
                                                                      // Check if the Piranha is 10 pixels of the ChickenLeg
                if (distance < 10)
                {
                    // "Eat" the ChickenLeg and basically gets removed
                    tokenManager.RemoveChickenLeg();
                    xSpeed = rand.Next(2, 6);// New speed between 2 and 5 horizontaly
                    ySpeed = 0;//stops verticall movement temporarly
                    return; //exits updates
                }

                // Adjust movement to the ChickenLeg.
                if (dx != 0) xDirection = Math.Sign(dx);// Move left or right based on the ChickenLeg position 
                if (dy != 0) yDirection = Math.Sign(dy);// Move up or down based on the ChickenLeg position
                                                        // Reference: GeeksforGeeks  C# Math.Sign() Method
                                                        // The Math.Sign() is used to determine the sign of a number
                                                        // visit: https://www.geeksforgeeks.org/c-sharp-math-sign-method/
                                                        // Move the Piranha towards the ChickenLeg with a speed of 6
                xPosition += (6 * dx) / distance;// makes horizontal movement normal
                yPosition += (6 * dy) / distance;// makes vertical movement normal 
            }
            else
            {
                // Normal horizontal and vertical movement when no ChickenLeg is present.
                if (xPosition > screen.width / 2 || xPosition < -screen.width / 2)
                {
                    xDirection *= -1; // Reverse horizontal direction when it hits edges.
                }

                if (yPosition > screen.height / 2 || yPosition < -screen.height / 2)
                {
                    yDirection *= -1; // Reverse vertical direction when it hits edges.
                }

                // Update position based on speed and direction
                xPosition += xSpeed * xDirection;
                yPosition += ySpeed * yDirection;
            }
        }

        /// METHOD: Draw
        /// Draws the Piranha token on the screen using its current properties.
        public void Draw(IGetAsset pAssetManager, SpriteBatch pSpriteBatch)
        {
            Asset currentAsset = pAssetManager.GetAssetByID(textureID); // Retrieve the texture asset.

            SpriteEffects horizontalDirection; // Determines if the sprite is flipped horizontally.

            // Set the sprite direction based on movement.
            if (xDirection < 0)
            {
                horizontalDirection = SpriteEffects.FlipHorizontally;
            }
            else
            {
                horizontalDirection = SpriteEffects.None;
            }

            // Draw the sprite at its current position.
            pSpriteBatch.Draw(currentAsset.Texture,// Texture.
                              new Vector2(xPosition, yPosition * -1), // Position.
                              null, // Source rectangle.
                              Color.White,// Tint color.
                              0f, // Rotation.
                              new Vector2(currentAsset.Size.X / 2, currentAsset.Size.Y / 2), // Origin.
                              new Vector2(1, 1), // Scale.
                              horizontalDirection, // Flip effect.
                              1);  // Layer depth.
        }
    }
}
