﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using FishORamaEngineLibrary;
using System.Windows.Forms.Design.Behavior;
using System.Reflection;

/* FISHORAMA24 | .NET 6.0 | C.Blythe */

namespace FishORama
{
    /// CLASS: Seahorses
    class Seahorses : IDraw
    {
        // CLASS VARIABLES
        // Properties for rendering and movement.
        private string textureID; // Texture asset for this token.
        private float xPosition; // X coordinate.
        private float yPosition; // Y coordinate
        private int xDirection; // Horizontal movement 
        private int yDirection; // Vertical movement
        private Screen screen; // Screen dimensions.
        private ITokenManager tokenManager; // Token manager

        // ADDITIONAL CLASS VARIABLES
        private int xSpeed; // Horizontal movement speed.
        private int ySpeed; // Vertical movement speed (used in the zig zag behaviour)
        private Random rand; // Random number generator

        // Sink/Rise.
        private bool sinking_rising; //tells us is seahorse is sinking or rising.
        private float guideY; //Position for sink/rise behavior.
        private float bandCenter; // Target y-position for sink/rise behavior.

        /// CONSTRUCTOR: Seahorses
        public Seahorses(string pTextureID, float pXpos, float pYpos, Screen pScreen, ITokenManager pTokenManager, Random pRand)
        {
            //Properties
            textureID = pTextureID;
            xPosition = pXpos;
            yPosition = pYpos;
            xDirection = 1;  
            yDirection = 1;  
            screen = pScreen;
            tokenManager = pTokenManager;
            rand = pRand;

            //movement properties.
            xSpeed = rand.Next(2, 6); // Gives a random speed between 2 and 5 
            ySpeed = xSpeed;          // Diagonal movement speed 45-degree angle.

            // Initialize sink/rise behavior control.
            sinking_rising = false; //sinking or rising is not active
            guideY = 0; // initial sink/rise movement
            bandCenter = yPosition;// Centerline will start at the initial Y position
        }

        /// METHOD: Update
        /// Updates the Seahorse's position and handles zig-zag and sink/rise behaviors.
        public void Update()
        {

            // Trigger sink or rise behavior within a 1 in 300 chance 
            if (!sinking_rising && rand.Next(300) == 0)
            {
                sinking_rising = true;  //sinking or rising is active

                // It decide whether to sink or rise based on the vertical direction
                guideY = yPosition + (100 * yDirection);

                // Stops if from leaving the screen or going out
                guideY = Math.Clamp(guideY, -screen.height / 2, screen.height / 2);
                // Reference: Educative.io - What is Math.Clamp in C#
                // The Math.Clamp() restricts a value to a specified range
                //visit: https://www.educative.io/answers/what-is-mathclamp-in-c-sharp
            }
            // Handle sink/rise 
            if (sinking_rising)
            {
                float speed = 1.0f;// this is a fixed speed for sink or rise.

                if (Math.Abs(yPosition - guideY) > speed) // Check if its far from the guide
                                                          // Reference: Codecademy - Math.Abs() in C#
                                                          // The Math.Abs() returns the absolute value of a number.
                                                          //visit: https://www.codecademy.com/resources/docs/c-sharp/math-functions/abs
                {
                    yPosition += Math.Sign(guideY - yPosition) * speed; // Move gradually toward the guide
                                                                        // Reference: GeeksforGeeks  C# Math.Sign() Method
                                                                        // The Math.Sign() is used to determine the sign of a number
                                                                        // visit: https://www.geeksforgeeks.org/c-sharp-math-sign-method/
                }
                else
                {
                    yPosition = guideY;       // Snap to the guide
                    sinking_rising = false; // stops the sink or rise behavior.
                    bandCenter = yPosition;   // Update band center for zig-zagging.
                }

                return; // Skip zig-zag behavior during the sink or rise.
            }
            if (yPosition >= bandCenter + 50 || yPosition <= bandCenter - 50) // This are the boundaries for the Zig-zag
            {
                yDirection *= -1; // Reverse direction.
            }

            // Handles screen boundary
            if (xPosition > screen.width / 2 || xPosition < -screen.width / 2)
            {
                xDirection *= -1;
            }
            // Handles screen boundary
            if (yPosition > screen.height / 2 || yPosition < -screen.height / 2)
            {
                yDirection *= -1;
            }
            // Update position 
            xPosition += xSpeed * xDirection; // Horizontal movement.
            yPosition += ySpeed * yDirection; // Vertical movement 
        }

        /// METHOD: Draw
        /// Renders the Seahorse token on the screen using its current properties.
        public void Draw(IGetAsset pAssetManager, SpriteBatch pSpriteBatch)
        {
            Asset currentAsset = pAssetManager.GetAssetByID(textureID); // Retrieve the texture asset.

            SpriteEffects horizontalDirection; // Determines if the sprite is flipped horizontally.

            // Set the sprite direction based on movement.
            if (xDirection < 0)
            {
                horizontalDirection = SpriteEffects.FlipHorizontally;
            }
            else
            {
                horizontalDirection = SpriteEffects.None;
            }

            // Draw the sprite at its current position.
            pSpriteBatch.Draw(currentAsset.Texture,// Texture.
                              new Vector2(xPosition, yPosition * -1), // Position (invert Y for screen coordinates).
                              null,// Source rectangle.
                              Color.White, // Tint color.
                              0f, // Rotation.
                              new Vector2(currentAsset.Size.X / 2, currentAsset.Size.Y / 2), // Origin (center of sprite).
                              new Vector2(1, 1), // Scale.
                              horizontalDirection, // Flip effect.
                              1); // Layer depth.
        }
    }
}
