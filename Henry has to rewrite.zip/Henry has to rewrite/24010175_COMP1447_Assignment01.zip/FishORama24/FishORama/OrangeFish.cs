﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using FishORamaEngineLibrary;

namespace FishORama
{
    /// CLASS: OrangeFish
    class OrangeFish : IDraw
    {
        // CLASS VARIABLES
        // Core properties 
        private string textureID; // texture asset 
        private float xPosition; // X coordinate 
        private float yPosition; // Y coordinate 
        private int xDirection; // Horizontal movement 
        private int yDirection; // Vertical movement
        private Screen screen;  // screen dimensions.
        private ITokenManager tokenManager;// token manager
        private int xSpeed; // Horizontal movement speed
        private int ySpeed; // Vertical movement speed
        private Random rand; // Random number generator 

        /// CONSTRUCTOR: OrangeFish
        public OrangeFish(string pTextureID, float pXpos, float pYpos, Screen pScreen, ITokenManager pTokenManager, Random pRand)
        {
   
            textureID = pTextureID;
            xPosition = pXpos;
            yPosition = pYpos;
            xDirection = 1;
            yDirection = 1; 
            screen = pScreen;
            tokenManager = pTokenManager;
            rand = pRand;
            xSpeed = rand.Next(2, 6); // Random horizontal speed between 2 and 5 
            ySpeed = xSpeed / 2;      // Vertical speed is divided by half
        }

        /// METHOD: Update
        public void Update()
        {
            //Basically handels collisions for horizontal movement.
            if (xPosition > screen.width / 2 || xPosition < -screen.width / 2)
            {
                xDirection *= -1; // Reverse horizontal direction

                // 25% chance to reverse vertical direction when hitting the left or right edge
                if (rand.Next(4) == 0)
                {
                    yDirection *= -1;
                }
            }

            // Handle collisions for vertical movement
            if (yPosition > screen.height / 2 || yPosition < -screen.height / 2)
            {
                yDirection *= -1; // Reverse vertical direction

                // 50% chance to reverse horizontal direction when hitting the top or bottom edge
                if (rand.Next(2) == 0)
                {
                    xDirection *= -1;
                }
            }

            // Update position 
            xPosition += xSpeed * xDirection; // Update horizontal position
            yPosition += ySpeed * yDirection; // Update vertical position
        }

        /// METHOD: Draw
        /// Renders the OrangeFish token on the screen using its current properties.
        public void Draw(IGetAsset pAssetManager, SpriteBatch pSpriteBatch)
        {
            Asset currentAsset = pAssetManager.GetAssetByID(textureID); // Retrieve the texture asset.

            SpriteEffects horizontalDirection; // Determines if the sprite is flipped horizontally.

            // Set the sprite direction based on movement.
            if (xDirection < 0)
            {
                horizontalDirection = SpriteEffects.FlipHorizontally;
            }
            else
            {
                horizontalDirection = SpriteEffects.None;
            }

            // Draw the sprite at its current position.
            pSpriteBatch.Draw(currentAsset.Texture, // Texture.
                              new Vector2(xPosition, yPosition * -1), // Position 
                              null,// Source rectangle.
                              Color.White,// Tint color.
                              0f, // Rotation.
                              new Vector2(currentAsset.Size.X / 2, currentAsset.Size.Y / 2), // Origin 
                              new Vector2(1, 1),  // Scale.
                              horizontalDirection, // Flip effect.
                              1); // Layer depth.
        }
    }
}
