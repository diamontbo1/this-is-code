﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using FishORamaEngineLibrary;


namespace FishORama
{

    /// CLASS: Simulation
    /// Manages all tokens in the simulation and their behaviors.
    /// This class is responsible for instantiating, managing, and updating the tokens in the FishORama aquarium.
    public class Simulation : IUpdate, ILoadContent
    {
        // CLASS VARIABLES
        // Variables store the information for the class
        private IKernel kernel; // Draws method for all token
        private Screen screen; // Screeen dimensions (width, height)
        private ITokenManager tokenManager; // TokenManager (for access to ChickenLeg)

        
        /// PROPERTIES
        public ITokenManager TokenManager // Access to the token manager.
        {
            set { tokenManager = value; }
        }


        // Variables for different tokens
        OrangeFish orangeFish1; //OrangeFish variable 
        Urchin[] UrchinArray = new Urchin[3]; // Array for Urchins (3)
        Seahorses[] SeahorsesArray = new Seahorses[5]; // Array for Seahorses (5)
        Piranha Piranha1; //Piranha variable 
        Random rand;// Generates random number (for speed and spawns)


        /// CONSTRUCTOR - for the Simulation class - run once only when an object of the Simulation class is INSTANTIATED (created)
        /// Use constructors to set up the state of a class
        public Simulation(IKernel pKernel)
        {
            kernel = pKernel;// Game engine kernel passed to the constructor when this class is created
            screen = kernel.Screen;// Sets the Screen
            rand = new Random(); // Generate random numbers


        }




        /// METHOD: LoadContent - called once at start of program
        /// Create all token objects and 'insert' them into the FishORama engine
        public void LoadContent(IGetAsset pAssetManager)
        {

            // OrangeFish (Only 1)

            int initXpos = rand.Next(-400, 401); //Random spawn horizontal
            int initYpos = rand.Next(-400, 401); //Random spawn vertical
            orangeFish1 = new OrangeFish("OrangeFish", initXpos, initYpos, screen, tokenManager, rand); //Create a orageFish                                                                                                    
            kernel.InsertToken(orangeFish1); //It adds it to kernel


            // Urchins (They are 3)
            for (int i = 0; i < UrchinArray.Length; i++)
            {
                int urchinX = rand.Next(-400, 401); //Random spawn horizontal
                int urchinY = rand.Next(-400, 401); //Random spawn vertical
                Urchin tempUrchin = new Urchin("Urchin", urchinX, urchinY, screen, tokenManager, rand); // Create a urchin
                UrchinArray[i] = tempUrchin; // It adds it to the array
                kernel.InsertToken(tempUrchin); // It adds it to kernel
            }


            // Seahorses (They are 5)
            for (int i = 0; i < SeahorsesArray.Length; i++)
            {
                int seahorsesX = rand.Next(-400, 401); //Random spawn horizontal
                int seahorsesY = rand.Next(-400, 401); //Random spawn vertical
                Seahorses tempSeahorse = new Seahorses("Seahorse", seahorsesX, seahorsesY, screen, tokenManager, rand); // Create a seahorse
                SeahorsesArray[i] = tempSeahorse; // It adds it to the array
                kernel.InsertToken(tempSeahorse); // It adds it to kernel
            }

            // Piranha (Only 1)
            int piranhaX = rand.Next(-400, 401); //Random spawn horizontal
            int piranhaY = rand.Next(-400, 401); //Random spawn vertical
            Piranha1 = new Piranha("Piranha1", piranhaX, piranhaY, screen, tokenManager, rand); //Create a piranha
            kernel.InsertToken(Piranha1); // It adds it to kernel
          
            //Rand.Next(-400, 401) this basically just spawns the tokens in a random position of the screen
            
        }



        /// METHOD: Update - called 60 times a second by the FishORama engine when the program is running
        /// Add all tokens so Update is called on them regularly
        public void Update(GameTime gameTime)
        {

            orangeFish1.Update(); // This basically update the orange fish

            foreach (Urchin fish in UrchinArray) // Updates the Urchin (They are 3)
            {

                fish.Update();

            }

            foreach (Seahorses seahorse in SeahorsesArray) // Updates the seahores (They are 5)
            {
                seahorse.Update();
            }

            Piranha1.Update(); // Updates the piranha 

        }
    }


}

