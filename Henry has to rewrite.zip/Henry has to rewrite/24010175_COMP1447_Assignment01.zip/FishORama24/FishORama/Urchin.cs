﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using FishORamaEngineLibrary;

namespace FishORama
{
    /// CLASS: Urchin
    class Urchin : IDraw
    {
        // CLASS VARIABLES
        private string textureID;// texture asset 
        private float xPosition; // X coordinate 
        private float yPosition; // Y coordinate
        private int xDirection; // Horizontal movement 
        private int yDirection; // Vertical movement 
        private Screen screen; // screen dimensions.
        private ITokenManager tokenManager;// token manager 
        private ChickenLeg chickenLeg; // Reference to ChickenLeg (so they can detect it)
        private bool scattering;  // tells us urchin is in scatter mode.
        private bool chickenLegProcessed; // tracks if ChickenLeg has already been processed
        private int xSpeed;// Horizontal movement speed
        private int ySpeed;// Vertical movement speed 
        private Random rand;  // Random number 

        /// CONSTRUCTOR: Urchin
        /// Urchin parameters
        public Urchin(string pTextureID, float pXpos, float pYpos, Screen pScreen, ITokenManager pTokenManager, Random pRand)
        {
            //Properties.
            textureID = pTextureID;
            xPosition = pXpos;
            yPosition = pYpos;
            xDirection = 1;  
            yDirection = 1; 
            screen = pScreen;
            tokenManager = pTokenManager;
            rand = pRand;
            scattering = false; //Scattering is not active
            chickenLegProcessed = false; // ChickenLeg will not be in the screen untill clicked 
            xSpeed = rand.Next(1, 4); // Random speed between 1 and 3 inclusive.
            ySpeed = 0;              // No vertical movement by default.
        }

        /// METHOD: Update
        /// Updates the Urchin's position and handles scatter behavior in response to the ChickenLeg.
        public void Update()
        {
            // Check for the  ChickenLeg in the screen.
            chickenLeg = tokenManager.ChickenLeg;

            if (chickenLeg != null && !scattering && !chickenLegProcessed)
            {
                //  scatter behavior if a new ChickenLeg is in the screen
                scattering = true; //scaterring is activated as the chickenleg has be activated
                chickenLegProcessed = true; //chickenleg is in the screen

                //Direction to move away from the ChickenLeg
                if (xPosition < chickenLeg.Position.X)
                {
                    xDirection = -1; // Move left
                }
                else
                {
                    xDirection = 1;  // Move right
                }
            }

            if (scattering)
            {
                //Move quickly away from the ChickenLeg if scattering is active
                xPosition += 6 * xDirection;

                // Check if the Urchin hits the edge of the screen
                if (xPosition >= screen.width / 2 || xPosition <= -screen.width / 2)
                {
                    xDirection *= -1; // Reverse direction 
                    xPosition = Math.Clamp(xPosition, -screen.width / 2 + 1, screen.width / 2 - 1); // Keep within the screen
                                                                                                    // Reference: Educative.io - What is Math.Clamp in C#
                                                                                                    // The Math.Clamp() restricts a value to a specified range
                                                                                                    //visit: https://www.educative.io/answers/what-is-mathclamp-in-c-sharp
                    scattering = false; // End of the scatter behavior
                }
            }
            else
            {
                // Return to normal behavior if no ChickenLeg is not in the screen
                if (chickenLeg == null)
                {
                    chickenLegProcessed = false; // Allow spaw of a new ChickenLeg
                }

                // Normal horizontal movement.
                if (xPosition > screen.width / 2 || xPosition < -screen.width / 2)
                {
                    xDirection *= -1; // Reverse direction 

                    // 25% chance to change direction vertically
                    if (rand.Next(4) == 0)
                    {
                        yDirection *= -1;
                    }
                }

                xPosition += xSpeed * xDirection; // Update position for normal movement.
            }
        }

        /// METHOD: Draw
        /// Renders the Urchin token on the screen using its current properties.
        public void Draw(IGetAsset pAssetManager, SpriteBatch pSpriteBatch)
        {
            Asset currentAsset = pAssetManager.GetAssetByID(textureID); // Retrieve the texture asset.

            SpriteEffects horizontalDirection; // Determines if the sprite is flipped horizontally.

            // Set the sprite direction based on movement.
            if (xDirection < 0)
            {
                horizontalDirection = SpriteEffects.FlipHorizontally;
            }
            else
            {
                horizontalDirection = SpriteEffects.None;
            }

            // Draw the sprite at its current position.
            pSpriteBatch.Draw(currentAsset.Texture, // Texture.
                              new Vector2(xPosition, yPosition * -1), // Position (invert Y for screen coordinates).
                              null, // Source rectangle.
                              Color.White, // Tint color.
                              0f, // Rotation.
                              new Vector2(currentAsset.Size.X / 2, currentAsset.Size.Y / 2), // Origin (center of sprite).
                              new Vector2(1, 1), // Scale.
                              horizontalDirection,  // Flip effect.
                              1);// Layer depth.
        }
    }
}
