﻿using Microsoft.Xna.Framework;

namespace FishORamaEngineLibrary
{
    public interface IUpdate
    {
        void Update(GameTime gameTime);
    }
}
