﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using FishORamaEngineLibrary;
using SharpDX.Direct3D9;

/* FISHORAMA24 | .NET 6.0 | C.Blythe */

namespace FishORama
{
    /// CLASS: Piranha - represents a token for the FishORama engine.
    /// Handles drawing the Piranha and controlling its movement.
    class Piranha : IDraw
    {
        // CLASS VARIABLES
        private string textureID;              
        private float xPosition;                
        private float yPosition;
        private int xDirection;
        private int yDirection;                 
        private Screen screen;                 
        private ITokenManager tokenManager;    
        private int xSpeed;                     
        private int ySpeed;                     
        private Random rand;                    ]
        /// CONSTRUCTOR: Initializes a Piranha instance with its starting state.
        public Piranha(string pTextureID, float pXpos, float pYpos, Screen pScreen, ITokenManager pTokenManager, Random pRand)
        {
            textureID = pTextureID;  
            xPosition = pXpos;       
            yPosition = pYpos;       
            xDirection = 1;          
            yDirection = 1;         
            screen = pScreen;        
            tokenManager = pTokenManager;  
            rand = pRand;            

            xSpeed = rand.Next(2, 6);    // Random speed between 2 and 5.
            ySpeed = 0;
            yPosition = rand.Next(0, (int)(screen.height * 0.66f)); // Start somewhere in the top of the screen
        }

        /// METHOD: Update - Handles the Piranha's movement and behavior.
        public void Update()
        {
            // Reverse direction if edges.
            if (xPosition > screen.width / 2 || xPosition < -screen.width / 2)
            {
                xDirection *= -1;  

                if (rand.Next(100) < 25)  
                {
                    yDirection *= -1;
                }
            }

            if (yPosition > screen.height / 2 || yPosition < -screen.height / 2)
            {
                yDirection *= -1;  

            }

            // Update position based on speed and direction.
            xPosition += xSpeed * xDirection;
            yPosition += ySpeed * yDirection;
        }

        /// METHOD: Draw - Renders the Piranha on the screen.
        /// This method is called by the FishORama engine to display the token.
        public void Draw(IGetAsset pAssetManager, SpriteBatch pSpriteBatch)
        {
            // Get the texture associated with this token.
            Asset currentAsset = pAssetManager.GetAssetByID(textureID);

            // Determine whether to flip the texture horizontally based on direction.
            SpriteEffects horizontalDirection = xDirection < 0 ? SpriteEffects.FlipHorizontally : SpriteEffects.None;

            // Draw the texture, centered at the Piranha's position.
            pSpriteBatch.Draw(
                currentAsset.Texture,                                             // Texture to draw.
                new Vector2(xPosition, yPosition * -1),                           // Position on the screen.
                null,                                                             // No source rectangle.
                Color.White,                                                      // No color tint.
                0f,                                                               // No rotation.
                new Vector2(currentAsset.Size.X / 2, currentAsset.Size.Y / 2),    // Center the texture.
                new Vector2(1, 1),                                                // Scale of 1x1.
                horizontalDirection,                                              // Flip or don't flip the texture.
                1                                                                 // Draw at layer depth 1.
            );
        }
    }
}
