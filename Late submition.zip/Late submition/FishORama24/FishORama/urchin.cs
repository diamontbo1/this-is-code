﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using FishORamaEngineLibrary;

namespace FishORama
{
    /// CLASS: Urchin - represents a token for the FishORama engine.
    /// Handles the movement and rendering of an Urchin in the simulation.
    class Urchin : IDraw
    {
        // CLASS VARIABLES
        private string textureID;       // ID of the texture used for this token.
        private float xPosition;        // Current X position 
        private float yPosition;        // Current Y position 
        private int xDirection;         // Horizontal movement (-1 = left, 1 = right).
        private int yDirection;         // Vertical movement  (-1 = down, 1 = up).
        private Screen screen;          // screen dimensions.
        private ITokenManager tokenManager; // token manager.

        // Movement-specific variables
        private int xSpeed;             // Speed of horizontal 
        private int ySpeed;             // Speed of vertical 
        private Random rand;            // Random number

        /// CONSTRUCTOR: Initializes the Urchin with starting properties.
        public Urchin(string pTextureID, float pXpos, float pYpos, Screen pScreen, ITokenManager pTokenManager, Random pRand)
        {
            textureID = pTextureID;  // Assign the texture ID.
            xPosition = pXpos;       // X position.
            yPosition = pYpos;       //  Y position.
            xDirection = 1;          // moving right.
            yDirection = 1;          // Up direction 
            screen = pScreen;        // Screen dimensions.
            tokenManager = pTokenManager;  // Token manager.
            rand = pRand;            // random number.

            xSpeed = rand.Next(1, 4);
            ySpeed = 0; // Urchin does not move up.
        }

        /// METHOD: Update - Handles Urchin movement.
        public void Update()
        {
            // Reverse if hitting edge.
            if (xPosition > screen.width / 2 || xPosition < -screen.width / 2)
            {
                xDirection *= -1; 

                if (rand.Next(100) < 25) // 25% chance to change direction up
                {
                    yDirection *= -1;
                }
            }

            // Update position 
            xPosition += xSpeed * xDirection;
            yPosition += ySpeed * yDirection;
        }

        /// METHOD: Draw - Renders the Urchin on the screen.
        /// This method is called repeatedly by the FishORama engine.
        public void Draw(IGetAsset pAssetManager, SpriteBatch pSpriteBatch)
        {
            // Get the texture for this token.
            Asset currentAsset = pAssetManager.GetAssetByID(textureID);

            // Determine whether to flip the texture horizontally.
            SpriteEffects horizontalDirection = xDirection < 0 ? SpriteEffects.FlipHorizontally : SpriteEffects.None;

            // Draw the texture, centered at the Urchin's position.
            pSpriteBatch.Draw(
                currentAsset.Texture,                                             // Texture to draw.
                new Vector2(xPosition, yPosition * -1),                           // Position on the screen.
                null,                                                             // No source rectangle.
                Color.White,                                                      // No color tint.
                0f,                                                               // No rotation.
                new Vector2(currentAsset.Size.X / 2, currentAsset.Size.Y / 2),    // Center the texture.
                new Vector2(1, 1),                                                // Scale (1x1).
                horizontalDirection,                                           
                1                                                                
            );
        }
    }
}
