﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using FishORamaEngineLibrary;

namespace FishORama
{

    public class FishSim : IUpdate, ILoadContent
    {
        private IKernel gameKernel;  
        private Screen gameScreen;  // The screen size
        private ITokenManager stuffManager; // Manages

        // This is for the chicken leg
        public ITokenManager StuffManager
        {
            set { stuffManager = value; }
        }

        // All the fish and things.
        OrangeFish orangefish;                       // The orange fish 
        Urchin[] urchin1 = new Urchin[3];  // A bunch of URCHIN (3 of them).
        Seahorses[] seahorses = new Seahorses[5]; // These are the seahorses (5 of them).
        Piranha piranha;                   // The pirahna
        Random rand;                    // Makes random numbers 

        // This happens when the simulation starts. Sets stuff up.
        public FishSim(IKernel kernelThing)
        {
            gameKernel = kernelThing;           // Save the main game 
            gameScreen = kernelThing.Screen;    // Get the screen size.
            rand = new Random();          // Make a random number
        }
        public void LoadContent(IGetAsset assetGrabber)
        {
            // Make the orange fish.
            int startX = rand.Next(-450, 451);  // Random X spot.
            int startY = rand.Next(-450, 451);
            orangefish = new OrangeFish("OrangeFish", startX, startY, gameScreen, stuffManager, rand); // Make the fish.
            gameKernel.InsertToken(orangefish);            // Add it to the game.

            // Make some spiky things.
            for (int i = 0; i < urchin1.Length; i++)
            {
                int spikeX = rand.Next(-450, 451);  
                int spikeY = rand.Next(-450, 451);  // Random Y spot.
                Urchin urchins = new Urchin("Urchin", spikeX, spikeY, gameScreen, stuffManager, rand); // Make a fish2 
                urchin1[i] = urchins;              // Save it in the list.
                gameKernel.InsertToken(urchins);       // Add it to the game.
            }

            // Make some seahorses.
            for (int i = 0; i < seahorses.Length; i++)
            {
                int horseX = rand.Next(-400, 401);  // Random X spot.
                int horseY = rand.Next(-400, 401);  // Random Y spot.
                Seahorses seahorses1 = new Seahorses("Seahorse", horseX, horseY, gameScreen, stuffManager, rand); // Make a fish3.
                seahorses[i] = seahorses1;              // Save it in the list.
                gameKernel.InsertToken(seahorses1);        // Add it to the game.
            }

            // Make the chompy fish.
            int chompX = rand.Next(-400, 401);  // Random X spot.
            int chompY = rand.Next(-400, 401);  // Random Y spot.
            piranha = new Piranha("Piranha1", chompX, chompY, gameScreen, stuffManager, rand); // Make the fish4.
            gameKernel.InsertToken(piranha);       // Add it to the game.
        }

        public void Update(GameTime gameTime)
        {
            orangefish.Update(); // Move the fish1.

            foreach (Urchin spike in urchin1) // Move all the fish2.
            {
                spike.Update();
            }

            foreach (Seahorses horse in seahorses) // Move all the fish3.
            {
                horse.Update();
            }

            piranha.Update(); // Move the fish4.
        }
    }
}
